<?php

namespace App\RestoModel;

use Illuminate\Database\Eloquent\Model;

class ProfileRT extends Model
{
    protected $table = 'res_info_tab';
    protected $primaryKey = 'res_info_id';
}
