<?php

namespace App\Http\Controllers\API\Restaurant;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class RestaurantOrderController extends Controller
{
    //
}
