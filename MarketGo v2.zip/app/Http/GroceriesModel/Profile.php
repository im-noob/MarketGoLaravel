<?php

namespace App\GroceriesModel;

use Illuminate\Database\Eloquent\Model;

class Profile extends Model
{
    protected $table = 'gro_shop_info_tab';
    protected $primaryKey = 'gro_shop_info_id';
}
